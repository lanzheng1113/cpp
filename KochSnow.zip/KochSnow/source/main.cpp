
//依赖 glew32.lib freeglut.lib

#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <iterator>     // std::ostream_iterator
#include <GL/glew.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/freeglut.h>
#include <math.h>
#include "shader.h"

#define PI 3.14159265
using namespace std;


void userInit();
void reshape(int w,int h);
void display( void );
void keyboardAction( unsigned char key, int x, int y );
void prepareData();

struct ShaderData {
GLuint vboId;           // vertex buffer object
GLuint vaoId;           // vertex array object
GLuint programId;       // shader program id
GLuint projMatLocId;    // projection matrix location id
GLuint viewMatLocId;    // view matrix location id
GLuint modelMatLocId;   // model matrix location id
glm::mat4 projMatrix;   // Store the projection matrix
glm::mat4 viewMatrix;   // Store the view matrix
glm::mat4 modelMatrix;  // Store the model matrix
}shader;

std::vector< glm::vec4 > vertexVec;


int main( int argc, char **argv )
{
	glutInit(&argc, argv);

    glutInitDisplayMode( GLUT_RGBA|GLUT_DOUBLE);
	glutInitWindowPosition(100,100);
    glutInitWindowSize( 512, 512 );
    glutCreateWindow( "Triangle demo" );

    glewInit();
    userInit();
	glutReshapeFunc(reshape);
    glutDisplayFunc( display );
    glutKeyboardFunc( keyboardAction );
    glutMainLoop();
    return 0;
}
//自定义初始化函数
void userInit()
{
	 glClearColor( 0.0, 0.0, 0.0, 0.0 );
	 //创建顶点数据
     prepareData();
	 //创建vertex array object对象
	 glGenVertexArrays(1,&shader.vaoId);
	 glBindVertexArray(shader.vaoId);
	 //创建vertex buffer object对象
	 glGenBuffers(1,&shader.vboId);
	 glBindBuffer(GL_ARRAY_BUFFER,shader.vboId);
	 glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec4)*vertexVec.size(),&vertexVec[0],GL_STATIC_DRAW);
	 glBindBuffer(GL_ARRAY_BUFFER,0);
	 //创建着色器
	std::vector<GLuint> idVector;
	idVector.push_back(Shader::createShader(GL_VERTEX_SHADER,"resources/vertex.glsl"));
	idVector.push_back(Shader::createShader(GL_FRAGMENT_SHADER,"resources/frag.glsl"));
	shader.programId = Shader::createProgram(idVector);
	//获取矩阵句柄
	shader.projMatLocId  = glGetUniformLocation(shader.programId, "projectionMatrix");
    shader.viewMatLocId  = glGetUniformLocation(shader.programId, "viewMatrix");
    shader.viewMatrix = glm::mat4(1.0);
    shader.modelMatLocId = glGetUniformLocation(shader.programId, "modelMatrix");
}
//调整窗口大小回调函数
void reshape(int w,int h)
{
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	//set projection matrix
	glUseProgram(shader.programId);
	if (w <= h) {
         shader.projMatrix = glm::ortho(-10.0,10.0,
        		 -10.0*(GLfloat)h/(GLfloat)w,10.0*(GLfloat)h/(GLfloat)w);
	}
	else {
		shader.projMatrix = glm::ortho(-10.0*(GLfloat)w/(GLfloat)h,
				10.0*(GLfloat)w/(GLfloat)h,-10.0,10.0);
	}
	glUniformMatrix4fv(shader.projMatLocId, 1,
	        GL_FALSE, glm::value_ptr(shader.projMatrix));
	glUseProgram(0);
}
//绘制回调函数
void display( void )
{
    glClear( GL_COLOR_BUFFER_BIT);
	glUseProgram(shader.programId);
	//send model matrix to shader
    shader.modelMatrix = glm::translate(glm::mat4(1.0f),glm::vec3(-5.0,5.0,0.0));
    glUniformMatrix4fv(shader.modelMatLocId, 1,
     GL_FALSE, glm::value_ptr(shader.modelMatrix));
    //send data to shader
	glBindBuffer(GL_ARRAY_BUFFER,shader.vboId);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0,4,GL_FLOAT,GL_FALSE,0,0);

	glDrawArrays(GL_LINE_LOOP, 0, vertexVec.size());

	glBindBuffer(GL_ARRAY_BUFFER,0);
	glUseProgram(0);
	glDisableVertexAttribArray(0);
	glutSwapBuffers();
}
//键盘按键回调函数
void keyboardAction( unsigned char key, int x, int y )
{
    switch( key )
	{
		case 033:  // Escape key
			exit( EXIT_SUCCESS );
			break;
    }
}
//prepare data
void prepareData()
{
    float side = 1.0f;
    int angle = 0;
    float x = 0,y =0;
    vertexVec.push_back(glm::vec4(x,y,0,1));
    for(int i=0;i< 3;i++)
    {
       x = x + (side/3)*cos(angle*PI / 180.0);
       y = y + (side/3)*sin(angle*PI/180.0);
        vertexVec.push_back(glm::vec4(x,y,0,1));

       angle += 60;
       x = x + (side/3)*cos(angle*PI / 180.0);
       y = y + (side/3)*sin(angle*PI/180.0);
        vertexVec.push_back(glm::vec4(x,y,0,1));

       angle += -120;
       x = x + (side/3)*cos(angle*PI / 180.0);
       y = y + (side/3)*sin(angle*PI/180.0);
        vertexVec.push_back(glm::vec4(x,y,0,1));

       angle += 60;
       x = x + (side/3)*cos(angle*PI / 180.0);
       y = y + (side/3)*sin(angle*PI/180.0);
        vertexVec.push_back(glm::vec4(x,y,0,1));

       angle += -120;
    }
    for(std::vector<glm::vec4>::size_type i = 0;i< vertexVec.size();++i)
    {
         glm::vec4 vec4 = vertexVec[i];
         cout<<vec4.x<<","<<vec4.y<<endl;
    }
}

